
#include <kipr/botball.h>
#include <apple.h>
int counter=0;
int main()
{
    printf("Hello World\n");
          enable_servos(); 
    set_servo_position(3,1795);
 msleep(10);// setting up naggers 
   
	mav(0,0);
    mav(1,0);
    msleep(3000);
    cmpc(0);
 while(gmpc(0)<=430){printf("just checking\n");
       mav(1,750);
       mav(0,750);
       msleep(300);// going to touch roomba was 1500///175

    if(digital(0)||digital(1)==1){counter=counter+1; printf("\ni like hows\n"); msleep(250);} }
     
    mav(1,-500);
    mav(0,-500);
    msleep(2000);// backing up from roomba



  
if(counter<1){/*place load in normal box*/printf("\n\n1st box Normal (no fire in 1st box)");}
else{/*put load in corner box*/printf("\n\n2nd box Corner. (FIRE in 1st box)");}

  
    mav(1,-1000);
    mav(0,-1000);
    msleep(2000);// leaving start boxxx
    
   mav(0,-100);
    mav(1,-1000);
    msleep(2200);// turning for blacl line
    
        mav(1,-1000);
    mav(0,-1000);
    msleep(2000);
    
      set_servo_position(3,500);
    
    msleep(10);
    
       mav(0,1000);
    mav(1,1000);
    msleep(4300);
    
  
     mav(0,100);
    mav(1,1000);
    msleep(2000);
   
    
  rightlinefollowslow(3000); 
    
   
    
    
    if(counter!=1){/*place load in normal box*/printf("\n\n1st box Normal no fire");
    rightlinefollowslow(6750);
                   mav(0,1000);
    mav(1,1000);
    msleep(1300);    
          set_servo_position(3,1795);
 msleep(10);
                                   mav(0,-1000);
    mav(1,-1000);
    msleep(1300);
                   
                  }
    
else{/*put load in corner box*/printf("\n\n2nd box Corner. FIRE");

    rightlinefollowslow(6900);
  mav(0,500);
    mav(1,100);
    msleep(2000);
                    mav(0,1000);
    mav(1,1000);
    msleep(2300);
              set_servo_position(3,1795);
 msleep(10);
     
                                       mav(0,-1000);
    mav(1,-1000);
    msleep(1300);
    }
    
  disable_servos();
    ao(); 
    return 0;
}
