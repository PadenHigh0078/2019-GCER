
#define leftIR 5
#define lightsensor 0
#define Rmotor 1
#define Lmotor 0
#define frontIR 1
void rightlinefollowslow(int distance) // forward
{
    cmpc(Rmotor);
    cmpc(Lmotor);
    while ((gmpc(Rmotor)+gmpc(Lmotor))/2 < distance)
    {
        printf("Hvery small pp\n");
        
        mav(Rmotor, .65*.95*  (3400 - analog(leftIR)));
     
        mav(Lmotor, .85*  analog(leftIR));
    }
}




void leftlinefollowslow(int distance) // forward
{
    cmpc(Rmotor);
    cmpc(Lmotor);
    while ((gmpc(Rmotor)+gmpc(Lmotor))/2 < distance)
    {
         printf("u wish\n");
        
        mav(Rmotor, .65*.50*     (3400 - analog(frontIR)));
     
        mav(Lmotor, .85*     analog(frontIR));
    }
}